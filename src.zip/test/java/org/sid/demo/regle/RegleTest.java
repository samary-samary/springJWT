package org.sid.demo.regle;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.sid.demo.model.Produit;
import org.sid.demo.model.Version;
import org.sid.demo.service.IservicePersistrance;

import java.util.Collections;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class RegleTest {
	  @Mock
	    private IservicePersistrance iservicePersistrance;

	    @InjectMocks
	    private Regle regle;

	    @Test
	    public void testMethodeRegleWhenIdGreaterThan10AndNextMontantIsGreater() {
	        Produit produit = new Produit();
	        produit.setId(11);
	        when(iservicePersistrance.getMontant()).thenReturn(10.0f).thenReturn(12.0f);
	        when(iservicePersistrance.listProduit(anyInt(), anyObject())).thenReturn(Collections.singletonList(produit));
	        when(iservicePersistrance.ListVersion(anyInt())).thenReturn(Collections.emptyList());
	        final String s = Regle.methodeRegle(10);
	        assertEquals("Cas1", s);
	    }

	    @Test
	    public void testMethodeRegleWhenIdLessThan10AndNextMontantIsGreater() {
	        Produit produit = new Produit();
	        produit.setId(9);
	        when(iservicePersistrance.getMontant()).thenReturn(10.0f).thenReturn(12.0f);
	        when(iservicePersistrance.listProduit(anyInt(), anyObject())).thenReturn(Collections.singletonList(produit));
	        when(iservicePersistrance.ListVersion(anyInt())).thenReturn(Collections.emptyList());
	        final String s = Regle.methodeRegle(9);
	        assertEquals("Cas2", s);
	    }

	    @Test
	    public void testMethodeRegleWhenIdGreaterThan10AndNextMontantIsLess() {
	        Produit produit = new Produit();
	        produit.setId(11);
	        when(iservicePersistrance.getMontant()).thenReturn(10.0f).thenReturn(8.0f);
	        when(iservicePersistrance.listProduit(anyInt(), anyObject())).thenReturn(Collections.singletonList(produit));
	        when(iservicePersistrance.ListVersion(anyInt())).thenReturn(Collections.emptyList());
	        final String s = Regle.methodeRegle(11);
	        assertEquals("Cas2", s);
	    }

	    @Test
	    public void testMethodeRegleWhenIdLessThan10AndNextMontantIsLess() {
	        Produit produit = new Produit();
	        produit.setId(9);
	        when(iservicePersistrance.getMontant()).thenReturn(10.0f).thenReturn(8.0f);
	        when(iservicePersistrance.listProduit(anyInt(), anyObject())).thenReturn(Collections.singletonList(produit));
	        when(iservicePersistrance.ListVersion(anyInt())).thenReturn(Collections.emptyList());
	        final String s = Regle.methodeRegle(9);
	        assertEquals("Cas2", s);
	    }

	    @Test
	    public void testGetMontant() {
	        when(iservicePersistrance.getMontant()).thenReturn(10.0f);
	        final float montant = Regle.getMontant();
	        assertEquals(10.0f, montant, 1);
	    }

	    @Test
	    public void testGetProduit() {
	        Produit produit = new Produit();
	        produit.setId(10);

	        when(iservicePersistrance.listProduit(anyInt(), anyObject())).thenReturn(Collections.singletonList(produit));
	        final Produit getproduit = Regle.getproduit(10);
	        assertEquals(10, getproduit.getId());
	    }

	    @Test
	    public void testListVersion() {
	        Version version = new Version();
	        version.setIdversion(1);

	        when(iservicePersistrance.ListVersion(anyInt())).thenReturn(Collections.singletonList(version));
	        final List<Version> versions = Regle.ListVersion(1);
	        assertEquals(version.getIdversion(), versions.get(0).getIdversion());
	    }

	    @Test
	    public void testListVersionForEmptyList() {
	        when(iservicePersistrance.ListVersion(anyInt())).thenReturn(Collections.emptyList());
	        final List<Version> versions = Regle.ListVersion(1);
	        assertNotNull(versions);
	        assertTrue(versions.isEmpty());
	    }
}
