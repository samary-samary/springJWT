package org.sid.demo.regle;


import static org.junit.Assert.*;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.sid.demo.Inter.IDescProd;
import org.sid.demo.model.Produit;
import org.sid.demo.service.IservicePersistrance;

@RunWith(MockitoJUnitRunner.class)
public class Regle2Test {

	@Mock
	IservicePersistrance iservicePersistrance;
	@Mock
	IDescProd idescProd;
	
	@InjectMocks
	private Regle2 regle2;
	
	
	@Test
	public void testTraitProdWithOneListElementNotEqualMontant1() {
		
		
		Produit produit1 = mock(Produit.class);
		List <Produit> produitList1 = Collections.singletonList(produit1);
        when(regle2.getProduit(anyInt(), eq("PA"))).thenReturn(produitList1);
        
        Produit produit2 = mock(Produit.class);
        List <Produit> produitList2 = Collections.singletonList(produit2);
        when(regle2.getProduit(anyInt(), eq("PB"))).thenReturn(produitList2);
        
        when(produit1.getMontant()).thenReturn(1.0f);
        when(produit2.getMontant()).thenReturn(1.1f);
        
        when(produit1.getDescription()).thenReturn("description");
        
        when(iservicePersistrance.updatProduit(anyInt(), anyString())).thenReturn(1);
        
        regle2.traitProd(produit1);
        
		verify(idescProd, times(1)).getDescProd(anyString());
		
		assertEquals(regle2.l1.get(0), regle2.l2.get(0));
	}
	
	
	@Test
	public void testTraitProdWithOneListElementNotEqualMontant2() {
		
		
		Produit produit1 = mock(Produit.class);
		List <Produit> produitList1 = Collections.singletonList(produit1);
        when(regle2.getProduit(anyInt(), eq("PA"))).thenReturn(produitList1);
        
        Produit produit2 = mock(Produit.class);
        List <Produit> produitList2 = Collections.singletonList(produit2);
        when(regle2.getProduit(anyInt(), eq("PB"))).thenReturn(produitList2);
        
        when(produit1.getMontant()).thenReturn(1.0f);
        when(produit2.getMontant()).thenReturn(1.1f);
        
        when(produit1.getDescription()).thenReturn("description");
        
        when(iservicePersistrance.updatProduit(anyInt(), anyString())).thenReturn(0);
        
        regle2.traitProd(produit1);
        
		verify(idescProd, times(1)).getDescProd(anyString());
		
		assertEquals(regle2.l1.size(), 1);
		assertEquals(regle2.l2.size(), 0);
	}
	
	@Test
	public void testTraitProdWithOneListElementNotEqualMontantDescriptionLengthEqualsZero() {
		
		
		Produit produit1 = mock(Produit.class);
		List <Produit> produitList1 = Collections.singletonList(produit1);
        when(regle2.getProduit(anyInt(), eq("PA"))).thenReturn(produitList1);
        
        Produit produit2 = mock(Produit.class);
        List <Produit> produitList2 = Collections.singletonList(produit2);
        when(regle2.getProduit(anyInt(), eq("PB"))).thenReturn(produitList2);
        
        when(produit1.getMontant()).thenReturn(1.0f);
        when(produit2.getMontant()).thenReturn(1.1f);
        
        when(produit1.getDescription()).thenReturn("");
        
        regle2.traitProd(produit1);
        
		verify(idescProd, times(0)).getDescProd(anyString());
		
		assertEquals(regle2.l1.size(), 0);
		assertEquals(regle2.l2.size(), 0);
	}
	
	
	@Test
	public void testTraitProdWithOneListElementEqualMontant() {
		
		
		Produit produit1 = mock(Produit.class);
		List <Produit> produitList1 = Collections.singletonList(produit1);
        when(regle2.getProduit(anyInt(), eq("PA"))).thenReturn(produitList1);
        
        Produit produit2 = mock(Produit.class);
        List <Produit> produitList2 = Collections.singletonList(produit2);
        when(regle2.getProduit(anyInt(), eq("PB"))).thenReturn(produitList2);
        
        when(produit1.getMontant()).thenReturn(1.0f);
        when(produit2.getMontant()).thenReturn(1.0f);
        
        when(produit1.getDescription()).thenReturn("description");
        
        regle2.traitProd(produit1);
        
		verify(idescProd, times(0)).getDescProd(anyString());
		
		assertEquals(regle2.l1.size(), 0);
		assertEquals(regle2.l2.size(), 0);
	}
	
	@Test
	public void testTraitProdWithMoreThanOneListElement1() {
		
		
		Produit produit1 = mock(Produit.class);
		List <Produit> produitList1 = Collections.singletonList(produit1);
        when(regle2.getProduit(anyInt(), eq("PA"))).thenReturn(produitList1);
        
        Produit produit2 = mock(Produit.class);
        List <Produit> produitList2 = new ArrayList<>();
        produitList2.add(produit2);
        produitList2.add(produit1);
        when(regle2.getProduit(anyInt(), eq("PB"))).thenReturn(produitList2);
        
        regle2.traitProd(produit1);
		
		assertEquals(regle2.l1.size(), 0);
		assertEquals(regle2.l2.size(), 0);
	}
	
	@Test
	public void testTraitProdWithMoreThanOneListElement2() {
		
		
		Produit produit1 = mock(Produit.class);
		Produit produit2 = mock(Produit.class);
		List <Produit> produitList1 = new ArrayList<>();
        produitList1.add(produit1);
        produitList1.add(produit2);
        when(regle2.getProduit(anyInt(), eq("PA"))).thenReturn(produitList1);
        
        
        when(regle2.getProduit(anyInt(), eq("PB"))).thenReturn(produitList1);
        
        regle2.traitProd(produit1);
		
		assertEquals(regle2.l1.size(), 0);
		assertEquals(regle2.l2.size(), 0);
	}
	
	
	@Test
	public void testGetProduit() {
		Produit produit = new Produit();
        produit.setId(2);
        List <Produit> produitList = Collections.singletonList(produit);
        when(iservicePersistrance.getProduitType(anyInt(), anyObject())).thenReturn(produitList);
        List <Produit> produits = regle2.getProduit(2, "PB");
        verify(iservicePersistrance, times(1)).getProduitType(anyInt(), anyString());
        assertEquals(produitList, produits);
	}

}