package org.sid.demo;
/*
import org.sid.demo.service.ClientService;
import org.sid.demo.service.ClientServiceImp;*/
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;

@SpringBootApplication
public class WebserviceRes1Application {

	public static void main(String[] args) {
		SpringApplication.run(WebserviceRes1Application.class, args);
	}
	
	
	
	

}
