package org.sid.demo.DAO;

import java.util.List;

import org.sid.demo.model.Client;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface ClientReposotory   extends JpaRepository<Client, Integer> {
	@Query("SELECT c FROM Client c")
	List<Client> findAllclientder(Pageable pageable);
}
