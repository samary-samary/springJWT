package org.sid.demo.Inter;

public interface IDescProd {
	
	String getDescProd(String type);

}
