package org.sid.demo.Inter;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

public class DescProdImp  implements IDescProd{

	Map<String,String> mse= new HashMap<>();
	@Override
	public String getDescProd(String type) {
		// TODO Auto-generated method stub
		return mse.get(type);
	}
	@PostConstruct
	private void init() {
		mse.put("PA", "DESPA");
		mse.put("PB", "DESPB");
	}

}
