package org.sid.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Version {
	@Id
	@GeneratedValue
	int idversion ;
	String description;
	public int getIdversion() {
		return idversion;
	}
	public void setIdversion(int idversion) {
		this.idversion = idversion;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "Version [idversion=" + idversion + ", description=" + description + "]";
	}
	
	

}
