package org.sid.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Produit {
	@Id
	@GeneratedValue
int id ;
String typep ;
String description ;

float montant;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getTypep() {
	return typep;
}
public void setTypep(String typep) {
	this.typep = typep;
}
public float getMontant() {
	return montant;
}
public void setMontant(float montant) {
	this.montant = montant;
}


public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
@Override
public String toString() {
	return "Produit [id=" + id + ", typep=" + typep + ", montant=" + montant + "]";
}



}
