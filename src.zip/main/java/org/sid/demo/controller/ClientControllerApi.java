package org.sid.demo.controller;
import java.util.List;

import org.sid.demo.model.*;
//import org.sid.demo.service.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ClientControllerApi {
	/*@Autowired
	ClientService cltService;
	
	@RequestMapping(value="/listclient1")
	public List<Client> publi1() {
		return cltService.getListClient();
		

	}
	
	//http://localhost:3035/listclient?page=0&size=1
	
	@RequestMapping(value="/listclient")
	public Page<Client> publi(int page ,int size) {
		return cltService.getListClient(page,size);
		

	}*/
}

	
	
