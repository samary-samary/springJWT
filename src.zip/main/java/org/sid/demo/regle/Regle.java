package org.sid.demo.regle;

import java.util.List;

import org.sid.demo.model.Produit;
import org.sid.demo.model.Version;
import org.sid.demo.service.IservicePersistrance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

@Component
public class Regle {
	
	static IservicePersistrance iservicePersistrance;
	static Produit produit;
	static float montant ;
	
	List<Version> ListVersion;
	@Autowired
	public Regle(IservicePersistrance iservicePersistrance) {
		affect( iservicePersistrance);
	}
	public static  void  affect(IservicePersistrance iservicePersistrance) {
		Regle.iservicePersistrance=iservicePersistrance;

	}

	
	public static  String  methodeRegle(int id ) {
		montant= getMontant();
		String res=null;
		if (getMontant()>montant && getproduit(id).getId()>10 )
		{
           ListVersion(getproduit(id).getId());
           res="Cas1";
           System.out.println("Cas1");
		}
		else
		{
	           ListVersion(id);
	           res="Cas2";
	           System.out.println("Cas2");
		}
		return res;
	}

	
	
	public static float getMontant() {
		return iservicePersistrance.getMontant();
		}

	
	public static Produit getproduit(int id ) {
		return iservicePersistrance.listProduit(id , new PageRequest(0,1)).get(0);
	}

	
	public static List<Version> ListVersion(int idversion) {

		return  iservicePersistrance.ListVersion(idversion);
	}
	

}
