package org.sid.demo.regle;

import java.util.*;

import org.sid.demo.Inter.IDescProd;
import org.sid.demo.model.Produit;
import org.sid.demo.model.Version;
import org.sid.demo.service.IservicePersistrance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

@Component
public class Regle2 {
	@Autowired
	IservicePersistrance iservicePersistrance;
	@Autowired
	IDescProd idescProd;
	List <Produit> l1= new ArrayList<Produit>();
	List <Produit> l2= new ArrayList<Produit>();

	
	public void traitProd(Produit p) {
		List <Produit> lpa=	getProduit(p.getId(),"PA");
		List <Produit> lpb=getProduit(p.getId(),"PB");
		int na=lpa.size();
		int nb=lpb.size();
		if(na==1 && nb==1)
		{
			
			if ((lpa.get(0).getMontant()!=lpb.get(0).getMontant()) && lpa.get(0).getDescription().length()!=0)
			{
				l1.add(lpa.get(0));
					String description=idescProd.getDescProd(lpa.get(0).getDescription());
					if(iservicePersistrance.updatProduit(lpa.get(0).getId(),description)> 0)
					{
						l2.add(lpa.get(0));
						System.out.println("1");
					}
					else
					{
						System.out.println("2");
					}
			}
			else
			{
				System.out.println("3");
			}
	
		}
		else
		{
			System.out.println("4");
		}
		
	}
	
	
	public List <Produit> getProduit( int id,String type) {		
		return  iservicePersistrance.getProduitType(id, type);		
	}

}
