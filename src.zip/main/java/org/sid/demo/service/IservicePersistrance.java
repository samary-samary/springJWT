package org.sid.demo.service;

import java.util.List;

import org.sid.demo.model.Produit;
import org.sid.demo.model.Version;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;;

public interface IservicePersistrance {
	
	public float getMontant() ;
	public List <Produit>listProduit(int id ,Pageable pageable) ;
	public List <Version> ListVersion(int idversion) ;
	public int updatProduit(int id,String typ);
	public List <Produit> getProduitType(int id ,String typep);

} 