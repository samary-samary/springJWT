package org.sid.demo.reposotory;

import java.util.List;

import org.sid.demo.model.Version;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface Iversion extends JpaRepository<Version, Integer>{
 @Query("from Version v where v.idversion = :idversion")
	public List <Version> getversion(@Param("idversion") int idversion);
}
