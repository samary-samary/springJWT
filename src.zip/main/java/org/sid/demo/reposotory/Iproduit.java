package org.sid.demo.reposotory;

import java.util.List;

import org.sid.demo.model.Parametre;
import org.sid.demo.model.Produit;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface Iproduit extends JpaRepository<Produit, Integer> {
	 @Query("from Produit p where p.id = :id order by p.id desc")
		public List <Produit> getProduit(@Param("id") int id,Pageable pageable);
	 @Transactional
	 @Modifying(clearAutomatically = true)
	 @Query("update Produit p set p.typep= :typep where p.id = :id")
		public int updatProduit(@Param("id") int id ,@Param("typep") String typep);
	 
	 @Query("from Produit p where p.id = :id and p.typep= :typep ")
		public List <Produit> getProduitType(@Param("id") int id ,@Param("typep") String typep);
	 
}
