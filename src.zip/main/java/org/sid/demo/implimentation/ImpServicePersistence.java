package org.sid.demo.implimentation;

import java.util.List;

import org.sid.demo.model.Produit;
import org.sid.demo.model.Version;
import org.sid.demo.reposotory.Iproduit;
import org.sid.demo.reposotory.Iversion;
import org.sid.demo.service.IservicePersistrance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

@Repository
public class ImpServicePersistence implements IservicePersistrance {
	@Autowired
	Iproduit produitRepo;
	@Autowired
	Iversion versionRepo; 
	@Override
	public float getMontant() {
		return produitRepo.findAll().get(0).getMontant();
	}

	@Override
	public List<Produit> listProduit(int id ,Pageable pageable) {
		 List<Produit>listProduit=  produitRepo.getProduit(id, pageable);
		
		return listProduit;
	}

	@Override
	public List<Version> ListVersion(int idversion) {
		 List<Version>listVersion=  versionRepo.getversion(idversion);
		return listVersion;
	}

	@Override
	public int updatProduit(int id,String typep ) {
		 return produitRepo.updatProduit(id, typep);
	}

	@Override
	public List<Produit> getProduitType(int id, String typep) {
		
		return 	produitRepo.getProduitType( id , typep);

	}

}
